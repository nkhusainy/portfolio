# nkhusainy.github.io

Kinan's Website

The link to my personal website is at https://nkhusainy.github.io/

The link to the template on GitHub is at https://github.com/nkhusainy/nkhusainy.github.io
